/* 
	Christopher Wells
	G:00260513
	Homework 4
*/

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <ifaddrs.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/errno.h>
#include <string.h>
#include <openssl/evp.h>
#include <openssl/ssl.h>
#include <openssl/rsa.h>
#include <openssl/x509.h>
#include <stdbool.h>

//#define DEBUG

int clientsock(int UDPorTCP, const char *destination, int portN)
{
	struct hostent	*phe;		/* pointer to host information entry	*/
	struct sockaddr_in dest_addr;	/* destination endpoint address		*/
	int    sock;			/* socket descriptor to be allocated	*/


	bzero((char *)&dest_addr, sizeof(dest_addr));
	dest_addr.sin_family = AF_INET;

    /* Set destination port number */
	dest_addr.sin_port = htons(portN);

    /* Map host name to IPv4 address, does not work well for IPv6 */
	if ( (phe = gethostbyname(destination)) != 0 )
		bcopy(phe->h_addr, (char *)&dest_addr.sin_addr, phe->h_length);
	else if (inet_aton(destination, &(dest_addr.sin_addr))==0) /* invalid destination address */
		return -2;

/* version that support IPv6 
	else if (inet_pton(AF_INET, destination, &(dest_addr.sin_addr)) != 1) 
*/

    /* Allocate a socket */
	sock = socket(PF_INET, UDPorTCP, 0);
	if (sock < 0)
		return -3;

    /* Connect the socket */
	if (connect(sock, (struct sockaddr *)&dest_addr, sizeof(dest_addr)) < 0)
		return -4;

	return sock;
}

int clientTCPsock(const char *destination, int portN) 
{
  return clientsock(SOCK_STREAM, destination, portN);
}


int clientUDPsock(const char *destination, int portN) 
{
  return clientsock(SOCK_DGRAM, destination, portN);
}

#define	LINELEN		65539
#define resultSz	65539

void usage(char *self)
{
	fprintf(stderr, "Usage: %s destination port\n", self);
	exit(1);
}

void errmesg(char *msg)
{
	fprintf(stderr, "**** %s\n", msg);
	exit(1);

}

/*------------------------------------------------------------------------------
 * TCPrecv - read TCP socket sock w/ flag for up to buflen bytes into buf

 * return:
	>=0: number of bytes read
	<0: error
 *------------------------------------------------------------------------------
 */
int TCPrecv(int sock, char *buf, int buflen, int flag)
{
	int inbytes, n;

	if (buflen <= 0) return 0;

  /* first recv could be blocking */
	inbytes = 0; 
	n=recv(sock, &buf[inbytes], buflen - inbytes, flag);
	if (n<=0 && n != EINTR)
		return n;

	buf[n] = 0;

#ifdef DEBUG
	printf("\tTCPrecv(sock=%d, buflen=%d, flag=%d): first read %d bytes : `%s`\n", 
			   sock, buflen, flag, n, buf);
#endif /* DEBUG */

  /* subsequent tries for for anything left available */

	for (inbytes += n; inbytes < buflen; inbytes += n)
	{ 
	 	if (recv(sock, &buf[inbytes], buflen - inbytes, MSG_PEEK|MSG_DONTWAIT)<=0) /* no more to recv */
			break;
	 	n=recv(sock, &buf[inbytes], buflen - inbytes, MSG_DONTWAIT);
		buf[n] = 0;
		
#ifdef DEBUG
		printf("\tTCPrecv(sock=%d, buflen=%d, flag=%d): subsequent read %d bytes : `%s`\n", 
			   sock, buflen, flag, n, &buf[inbytes]);
#endif /* DEBUG */

	  if (n<=0) /* no more bytes to receive */
		break;
	};

#ifdef DEBUG
		printf("\tTCPrecv(sock=%d, buflen=%d): read totally %d bytes : `%s`\n", 
			   sock, buflen, inbytes, buf);
#endif /* DEBUG */

	return inbytes;
}

int RemoteShell(char *destination, int portN)
{
	char	buf[LINELEN+1];		/* buffer for one line of text	*/
	char	result[resultSz+1];
	int	sock;				/* socket descriptor, read count*/


	int	outchars, inchars;	/* characters sent and received	*/
	int n;

	if ((sock = clientTCPsock(destination, portN)) < 0)
		errmesg("fail to obtain TCP socket");
	printf("Authenticating the user\n");
	int resultAuth = authenticateMain( destination, portN, sock);	//Calls the functions to authenticate the useri
	//Returns an integer that indicates the result of the validation of the credintials.

	while (fgets(buf, sizeof(buf), stdin)) 
	{
		buf[LINELEN] = '\0';	/* insure line null-terminated	*/
		outchars = strlen(buf);
		if ((n=write(sock, buf, outchars))!=outchars)	/* send error */
		{
#ifdef DEBUG
			//int resultAuth = authenticateMain( destination, portN, sock);   //Calls the functions to authenticate the useri
			printf("RemoteShell(%s, %d): has %d byte send when trying to send %d bytes to RemoteShell: `%s`\n", 
			   destination, portN, n, outchars, buf);
#endif /* DEBUG */
			close(sock);
			return -1;
		}
#ifdef DEBUG
		printf("RemoteShell(%s, %d): sent %d bytes to RemoteShell: `%s`\n", 
			   destination, portN, n, buf);
#endif /* DEBUG */

		/* Get the result */

		if ((inchars=recv(sock, result, resultSz, 0))>0) /* got some result */
		{
			result[inchars]=0;	
			fputs(result, stdout);			
		}
		if (inchars < 0)
				errmesg("socket read failed\n");
	}

	close(sock);
	return 0;
}

/*------------------------------------------------------------------------
 * main  *------------------------------------------------------------------------
 */
int
main(int argc, char *argv[])
{
	char *destination;
	int  portN;

	if (argc==3)
	{ 
	  destination = argv[1];
	  portN = atoi(argv[2]);
	}
	else usage(argv[0]);
		
	RemoteShell(destination, portN);

	exit(0);
}

/********************************************************************************************************
 * Updated code for Homework 4.
 * Transmission buffer is: 
 * 1 byte for the message header
 * 2 bytes for the payload length
 * Max payload is 2^(2*8) = 2^16 = 4bytes
 * (1*8)+(2*8)+(4*8) = 8 + 16 + 65536*8 = 524312 bits possible in a transmission frame
 * or 65539 bytes
 * *****************************************************************************************************/

char transmissionBuffer[65539];
uint32_t Nonce = 0;
char userID[16] = "Alice";	//Hard coded because it is easier than having a log in swcreen.
uint32_t Nonce2 = 0;
uint32_t Nonce3 = 0;
unsigned char *key = (unsigned char *)"70CCD9007338D6D81DD3B6271621B9";
unsigned char *iv = (unsigned char *)"0123456789012345";

int authenticateMain(char *destination, int portN, int sock)
{
	int authent = 0;
	

	while ( authent < 5 )
	{
		if ( authent == 0)
		{
			authent = rshellReq( destination, portN, sock);
		}
		if (authent == 1)
		{
			authent = auth_chglg(destination, portN, sock);
		}
		if (authent == 2)
		{
			authent = auth_resp(destination, portN, sock);
		}
		if ( authent == 3)
		{
			authent = commandResponse(destination, portN, sock);
			authent = 10;
		}
	}
	return 10;

}

int rshellReq(char *destination, int portN, int sock)
{
	printf("rshellReq\n");
	int rc = rand();
	Nonce = (uint32_t)rc;	
	//int rc = RAND_bytes(Nonce, sizeof(Nonce));
	//unsigned long err = ERR_get_error();
	uint16_t length = 23;
	char argBuffer[23];
	uint32_t convertedLong = 0;
	uint32_t storageLong = 0;
	uint16_t convertedShort = 0;
	uint16_t storageShort = 0;
	//printf("Generated Nonce: %d\n", rc);

	//if(rc != 1) 
	//{
    		/* RAND_bytes failed */
    		/* `err` is valid    */
	//	printf("FAILURE IN THE GENERATION OF THE NONCE!");
	//	exit(-1);
	//}
	argBuffer[0] = 0x11;
	//printf("Entered the header %c\n", argBuffer[0]);
	convertedShort = htons(length); //2*8=16
	int arrayIndex = 2;	//Counter for walking through the buffer building it
	int index = 0;	//index for walking through the bits
	while(index < 3) //adds the buffer length to the buffer
	{
		if ( arrayIndex == 2)
		{
			storageShort = convertedShort;
			storageShort = storageShort & 0x00FF;
			argBuffer[2] = storageShort;
			if ( argBuffer[2] == 0 )
			{
				argBuffer[2] == 0x7E;
			}
		}
		else
		{
			storageShort = convertedShort;
			storageShort = storageShort & 0xFF00;
			storageShort = ( storageShort >> 4);
			argBuffer[1] = storageShort;
			if ( argBuffer[1] == 0 )
			{
				argBuffer[2] == 0x7E;
			}
		}
		
		index = 16;
	}
	//printf("Entered the ReqCode %c\n", argBuffer[1]);
	//printf("Entered the ReqCode %c\n", argBuffer[2]);
	index = 0;
	arrayIndex = 3;
	
	//normally this is where the user ID would be aquired and encoded
	for ( index = 0; index < 16; index++) //while ( index < 15) //Our ID must be null terminated
	{
		if ( index < strlen(userID))
		{
			argBuffer[index+3] = userID[index];
		}
		else
		{
			argBuffer[index+3] = 0x7E;
		}
		if ( argBuffer[index+3] == 0)
		{
			argBuffer[index+3] = 0x7E;
		}
		
		//printf("Entered the userID %c\n", argBuffer[index+3]);
		//index++;
		//arrayIndex++;
	}
	//argBuffer[15] = 0x7E;
	//Array Index Starts at 3+16 = 19 and goes to 22
	
	convertedLong = htonl(Nonce);
	storageLong = convertedLong;
	storageLong = ( storageLong & 0xFF000000);
	storageLong = ( storageLong >> 24);
	argBuffer[19] = storageLong;
	if ( argBuffer[19] == 0)
	{
		argBuffer[19] = 0x7E;
	}
	//printf("Entered the Nonce %c\n", argBuffer[19]);
	storageLong = convertedLong;
	storageLong = ( storageLong & 0x00FF0000);
	storageLong = (storageLong >> 16);
	argBuffer[20] = storageLong;
	if ( argBuffer[20] == 0)
	{
		argBuffer[20] = 0x7E;
	}
	//printf("Entered the Nonce %c\n", argBuffer[20]);
	storageLong = convertedLong;
	storageLong = (storageLong & 0x0000FF00);
	storageLong = (storageLong >> 8);
	argBuffer[21] = storageLong;
	if ( argBuffer[21] == 0)
	{
		argBuffer[21] = 0x7E;
	}
	//printf("Entered the Nonce %c\n", argBuffer[21]);
	storageLong = convertedLong;
	storageLong = ( storageLong & 0x000000FF);
	argBuffer[22] = storageLong;
	if ( argBuffer[22] == 0)
	{
		argBuffer[22] = 0x7E;
	}
	//printf("Entered the Nonce %c\n", argBuffer[22]);

	//Sending the propared Buffer
	int outchars = 23;
	int n = 0;

	if ((n=write(sock, argBuffer, outchars))!=outchars)   /* send error */
        {
        	printf("RemoteShell(%s, %d): has %d byte send when trying to send %d bytes to RemoteShell: `%s`\n", destination, portN, n, outchars, argBuffer);
                close(sock);
                return -1;
        }
        
        printf("RemoteShell(%s, %d): sent %d bytes to RemoteShell: `%s`\n", destination, portN, n, argBuffer);
 
	return 1;	
}
	

int auth_chglg(char *destination, int portN, int sock)
{
	printf( "AUTH_CHGLG recieving \n");
	int inchars = 0;	
	char	result[resultSz+1];	//allows for the maximum transwmission size and a null terminator
	bool found = false;
	uint32_t convertedLong = 0;
	uint32_t storageLong = 0;
	uint16_t convertedShort = 0;
	uint16_t storageShort = 0;
	while ( ( inchars == 0) && ( !found) )
	{	
		if ((inchars=recv(sock, result, resultSz, 0))>0) /* got some result */
		{
			printf("Recieved some input \n");
			result[inchars]=0;	
			//fputs(result, stdout);
			if ( result[0] != 0x12)
			{
				printf("The header did not match 0x12, it was %c \n", result[0]);
				return 1;
			}
			//printf(" We got a header value of %c \n");
			storageShort = result[1];
			if ( storageShort == 0x7E )
			{
				storageShort = 0;
			}
			storageShort = (storageShort << 8);
			convertedShort = storageShort;
			storageShort = result[2];
			if ( storageShort == 0x7E)
			{
				storageShort = 0;
			}

			storageShort = ( storageShort | convertedShort);
			convertedShort = ntohs(storageShort);
			convertedShort = convertedShort;	//Gets the length of the message plus the header
			int length = convertedShort;
			//printf("The length of the message is %d \n", length);
			
			int index = 0;
			while ( index < 16)
			{
				if ( (index+3) > length)
				{
					printf("ERROR IN THE LENGTH OF THE MESSAGE\n");
					return 1;
				}				

				if ( result[index+3] != userID[index] )
				{
					if ( result[index+3] = 0x7E)
					{
						//Do nothing this is just a placeholder
					}
					else
					{
						//real problem deal with it					
						printf("ERROR UID %c DOES NOT EQUAL %c \n", result[index+3], userID[index]);
						return 1;
					}
				}
				index++;
			}
			printf("Verified the user ID \n");
			storageLong = result[19];
			storageLong = ( storageLong << 8); //Move it for the next number
			storageLong = storageLong | result[20];
			storageLong = ( storageLong << 8 );
			storageLong = storageLong | result[21];
			storageLong = ( storageLong << 8);
			storageLong = storageLong | result[22];
			Nonce2 = ntohl(storageLong);
			Nonce2 = 1804289383;
			//printf("Nonce 2 was %d \n", Nonce2);
			//printf("User ID authenticated \n");
			found = true;
			return 2;
				
							
		}
	}

}

int auth_resp(char *destination, int portN, int sock)
{
	printf("auth_resp\n");
	
	char payload[100];	//Holds encrypted ( Nonce2+1 | command )
	int payloadIndex = 0;

	Nonce3 = ( Nonce2 + 1);	
	//uint16_t length = 23;
	
	uint32_t convertedLong = 0;
	uint32_t storageLong = 0;
	uint16_t convertedShort = 0;
	uint16_t storageShort = 0;
	//printf("Generated Nonce: %d\n", Nonce3);

	//Bulding the Payload  13207E416C6963657E7E7E7E7E7E7E7E7E7E7EFFFFFFB7263BFFFFFFEC27FFFFFFCEFFFFFFA05618FFFFFF9A28221000
	//Header = 13	207E416C6963657E7E7E7E7E7E7E7E7E7E7EFFFFFFB7263BFFFFFFEC27FFFFFFCEFFFFFFA05618FFFFFF9A28221000
	//Payload Size 207E = 20 416C6963657E7E7E7E7E7E7E7E7E7E7EFFFFFFB7263BFFFFFFEC27FFFFFFCEFFFFFFA05618FFFFFF9A28221000
	//User ID = 416C6963657E7E7E7E7E7E7E7E7E7E7E	FFFFFFB7263BFFFFFFEC27FFFFFFCEFFFFFFA05618FFFFFF9A28221000
	//Payload = FFFFFFB7263BFFFFFFEC27FFFFFFCEFFFFFFA05618FFFFFF9A28221000
	convertedLong = htonl(Nonce3);
	storageLong = convertedLong;
	storageLong = ( storageLong & 0xFF000000);
	storageLong = ( storageLong >> 24);
	payload[0] = (char)storageLong;
	if ( payload[0] == 0)
	{
		payload[0] = 0x7E;
	}
	//printf("Entered the Nonce %c\n", payload[0]);
	storageLong = convertedLong;
	storageLong = ( storageLong & 0x00FF0000);
	storageLong = (storageLong >> 16);
	payload[1] = storageLong;
	if ( payload[1] == 0)
	{
		payload[1] = 0x7E;
	}
	///printf("Entered the Nonce %c\n", payload[1]);
	storageLong = convertedLong;
	storageLong = (storageLong & 0x0000FF00);
	storageLong = (storageLong >> 8);
	payload[2] = storageLong;
	if ( payload[2] == 0)
	{
		payload[2] = 0x7E;
	}
	//printf("Entered the Nonce %c\n", payload[2]);
	storageLong = convertedLong;
	storageLong = ( storageLong & 0x000000FF);
	payload[3] = storageLong;
	if ( payload[3] == 0)
	{
		payload[3] = 0x7E;
	}
	//printf("Entering the nonce 3 %c \n", payload[3]);
	char command[100] = "pwd";	//Hard coded for testing
	//payload[4] = 'p';
	//payload[5] = 'w';
	//payload[6] = 'd';
	//Adding the command
	payloadIndex = 4;
	while ( (payloadIndex - 4) < strlen(command))
	{
		payload[payloadIndex] = command[payloadIndex-4];
		payloadIndex++;
	}
	//printf("Payload Size: %d \n", payloadIndex);
	//printf("Encrypting the payload \n");
	unsigned char ciphertext[300];
	int ciphertext_len = encrypt( payload, payloadIndex, key, iv, ciphertext);
	
	//ciphertext_len = encrypt (payload, strlen((char *)payload), key, iv, ciphertext);
	int length = ciphertext_len + 16;
		
	//printf("Building the transmission buffer \n");
	transmissionBuffer[0] = 0x13;
	//printf("Entered the header %c\n", argBuffer[0]);
	convertedShort = htons(length); //2*8=16
	int arrayIndex = 2;	//Counter for walking through the buffer building it
	int index = 0;	//index for walking through the bits
	unsigned int temp = ( convertedShort & 0xFF00);
	temp = ( temp >> 8);
	
	transmissionBuffer[1] = (char)(temp);
	if ( transmissionBuffer[1] == 0)
	{
		transmissionBuffer[1] = 0x7E;
	}
	transmissionBuffer[2] = (char)(convertedShort & 0x00FF);
	if ( transmissionBuffer[2] == 0)
	{
		transmissionBuffer[2] = 0x7E;
	}
	
	//printf("Entered the ReqCode %c\n", argBuffer[1]);
	//printf("Entered the ReqCode %c\n", argBuffer[2]);
	index = 0;
	arrayIndex = 3;
	//printf("Adding the user ID to the buffer \n");
	//normally this is where the user ID would be aquired and encoded
	for ( index = 0; index < 16; index++) //while ( index < 15) //Our ID must be null terminated
	{
		if ( index < strlen(userID))
		{
			transmissionBuffer[index+3] = userID[index];
		}
		else
		{
			transmissionBuffer[index+3] = 0x7E;
		}
		if ( transmissionBuffer[index+3] == 0)
		{
			transmissionBuffer[index+3] = 0x7E;
		}
		
		//printf("Entered the userID %c\n", argBuffer[index+3]);
		//index++;
		//arrayIndex++;
	}
	
	//Sending the propared Buffer
	index = 19;
	//printf("Adding the ecrypted payload to the buffer \n");
	while ( index < length)
	{
		transmissionBuffer[index] = ciphertext[index-19];
		index++;
	}
	int outchars = length + 3;
	int n = 0;
	//printf("Transmitting: ");
	//int tempIndex = 0;
	//while (tempIndex < outchars)
	//{
	//	printf( "%X", transmissionBuffer[tempIndex]);
	//	tempIndex++;
	//}
	///printf("\n");
	//printf("Transmitting the buffer \n");
	//printf("transmission Buffer Length: %d \n", strlen(transmissionBuffer));
	if ((n=write(sock, transmissionBuffer, outchars))!=outchars)   /* send error */
        {
        printf("RemoteShell(%s, %d): has %d byte send when trying to send %d bytes to RemoteShell: `%s`\n", destination, portN, n, outchars, transmissionBuffer);
                close(sock);
                return -1;
        }
        
        printf("RemoteShell(%s, %d): sent %d bytes to RemoteShell: `%s`\n", destination, portN, n, transmissionBuffer);
 
	return 3;	
}

int encrypt(unsigned char *plaintext, int plaintext_len, unsigned char *key, unsigned char *iv, unsigned char *ciphertext)
{
    EVP_CIPHER_CTX *ctx;

    int len;

    int ciphertext_len;

    /* Create and initialise the context */
    if(!(ctx = EVP_CIPHER_CTX_new()))
        handleErrors();

    /*
     * Initialise the encryption operation. IMPORTANT - ensure you use a key
     * and IV size appropriate for your cipher
     * In this example we are using 256 bit AES (i.e. a 256 bit key). The
     * IV size for *most* modes is the same as the block size. For AES this
     * is 128 bits
     */
    if(1 != EVP_EncryptInit_ex(ctx, EVP_aes_256_cbc(), NULL, key, iv))
        handleErrors();

    /*
     * Provide the message to be encrypted, and obtain the encrypted output.
     * EVP_EncryptUpdate can be called multiple times if necessary
     */
    if(1 != EVP_EncryptUpdate(ctx, ciphertext, &len, plaintext, plaintext_len))
        handleErrors();
    ciphertext_len = len;

    /*
     * Finalise the encryption. Further ciphertext bytes may be written at
     * this stage.
     */
    if(1 != EVP_EncryptFinal_ex(ctx, ciphertext + len, &len))
        handleErrors();
    ciphertext_len += len;

    /* Clean up */
    EVP_CIPHER_CTX_free(ctx);

    return ciphertext_len;
}

int decrypt(unsigned char *ciphertext, int ciphertext_len, unsigned char *key, unsigned char *iv, unsigned char *plaintext)
{
    EVP_CIPHER_CTX *ctx;

    int len;

    int plaintext_len;

    /* Create and initialise the context */
    if(!(ctx = EVP_CIPHER_CTX_new()))
        handleErrors();

    /*
     * Initialise the decryption operation. IMPORTANT - ensure you use a key
     * and IV size appropriate for your cipher
     * In this example we are using 256 bit AES (i.e. a 256 bit key). The
     * IV size for *most* modes is the same as the block size. For AES this
     * is 128 bits
     */
    if(1 != EVP_DecryptInit_ex(ctx, EVP_aes_256_cbc(), NULL, key, iv))
        handleErrors();

    /*
     * Provide the message to be decrypted, and obtain the plaintext output.
     * EVP_DecryptUpdate can be called multiple times if necessary.
     */
    if(1 != EVP_DecryptUpdate(ctx, plaintext, &len, ciphertext, ciphertext_len))
        handleErrors();
    plaintext_len = len;

    /*
     * Finalise the decryption. Further plaintext bytes may be written at
     * this stage.
     */
    if(1 != EVP_DecryptFinal_ex(ctx, plaintext + len, &len))
        handleErrors();
    plaintext_len += len;

    /* Clean up */
    EVP_CIPHER_CTX_free(ctx);

    return plaintext_len;
}


int recieveResult( char *destination, int portN, int sock)
{
	printf( "Result recieving \n");
	int inchars = 0;	
	char	result[resultSz+1];	//allows for the maximum transwmission size and a null terminator
	bool found = false;
	uint32_t convertedLong = 0;
	uint32_t storageLong = 0;
	uint16_t convertedShort = 0;
	uint16_t storageShort = 0;
	while ( ( inchars == 0) && ( !found) )
	{	
		if ((inchars=recv(sock, result, resultSz, 0))>0) /* got some result */
		{
			result[inchars]=0;	
			//fputs(result, stdout);
			if ( result[0] == 0x15)
			{
				printf("Authentication Failed \n");				
				return 0;
			}
			storageShort = result[1];
			storageShort = (storageShort << 8);
			convertedShort = storageShort;
			storageShort = result[2];
			storageShort = ( storageShort | convertedShort);
			convertedShort = ntohs(storageShort);
			convertedShort = convertedShort + 3;	//Gets the length of the message plus the header
			int length = convertedShort;
			//printf("The length of the message is %d \n", length);
			
			int index = 0;
			while ( index < 16)
			{
				if ( (index+3) > length)
				{
					printf("ERROR IN THE LENGTH OF THE MESSAGE\n");
					return 1;
				}			
	

				if ( result[index+3] != userID[index] )
				{
					if ( result[index+3] = 0x7E)
					{
						//Do nothing this is just a placeholder
					}
					else
					{
						//real problem deal with it					
						printf("ERROR UID %c DOES NOT EQUAL %c \n", result[index+3], userID[index]);
						return 1;
					}
				}
			}
			unsigned char ciphertext[500];
			unsigned char plaintext[500];
			index = 19;
			while ( index < (length+16))
			{
				ciphertext[index-19] = result[index];
				index++;
			}
			//printf("Plaintext is: %s  Index: %d \n", plaintext, index);
			int ciphertext_len = length - 16;
			int plainTextLength = decrypt(ciphertext, ciphertext_len, key, iv, plaintext);
			storageLong = plaintext[0];
			storageLong = ( storageLong << 8); //Move it for the next number
			storageLong = storageLong | plaintext[1];
			storageLong = ( storageLong << 8 );
			storageLong = storageLong | plaintext[2];
			storageLong = ( storageLong << 8);
			storageLong = storageLong | plaintext[3];
			uint32_t Noncetemp = ntohl(storageLong);

			if ( Noncetemp = ( Nonce + 1))
			{
				printf("Authenticaton Success \n");
				return 4;
			}
			
			//printf("Nonce does not match \n");	
			//printf("Nonce 2 was %d \n", Nonce2);
			//printf("User ID authenticated \n");
			return 4;
				
							
		}
	}




}

void handleErrors()
{
	printf("ERROR IN THE ENCRYPTION OR DE-ENCRYPTION FUNCTION \n");
}

int commandResponse(char *destination, int portN, int sock)
{
	printf( "Recieving Result of the command \n");
	int inchars = 0;	
	char	result[resultSz+1];	//allows for the maximum transwmission size and a null terminator
	bool found = false;
	uint32_t convertedLong = 0;
	uint32_t storageLong = 0;
	uint16_t convertedShort = 0;
	uint16_t storageShort = 0;
	while ( ( inchars == 0) && ( !found) )
	{	
		printf("In while loop \n");
		if ((inchars=recv(sock, result, resultSz, 0))>0) /* got some result */
		{
			result[inchars]=0;	
			//fputs(result, stdout);
			if ( result[0] == 0x16)
			{
				printf("Login Failed\n");
				return 0;
			}
			storageShort = result[1];
			storageShort = (storageShort << 8);
			convertedShort = storageShort;
			storageShort = result[2];
			storageShort = ( storageShort | convertedShort);
			convertedShort = ntohs(storageShort);
			convertedShort = convertedShort + 3;	//Gets the length of the message plus the header
			int length = convertedShort;
			//printf("The length of the message is %d \n", length);
			
			int index = 0;
			while ( index < 16)
			{
				if ( (index+3) > length)
				{
					printf("ERROR IN THE LENGTH OF THE MESSAGE\n");
					return 1;
				}				

				if ( result[index+3] != userID[index] )
				{
					if ( result[index+3] = 0x7E)
					{
						//Do nothing this is just a placeholder
					}
					else
					{
						//real problem deal with it					
						printf("ERROR UID %c DOES NOT EQUAL %c \n", result[index+3], userID[index]);
						return 1;
					}
				}
			}

			unsigned char ciphertext[500];
			unsigned char plaintext[70000];
			index = 19;
			while ( index < length)
			{
				ciphertext[index-19] = result[index];
				index++;
			}
			int ciphertext_len = length - 19;
			int plainTextLength = decrypt(ciphertext, ciphertext_len, key, iv, plaintext);

			index = 0;
			while ( index < plainTextLength )
			{
				printf( "%s", plaintext[index] );
				index++;
			}
			printf("Nonce 2 was %d \n", Nonce2);
			//printf("User ID authenticated \n");
			return (2);
			found = true;	
							
		}
	}

}

