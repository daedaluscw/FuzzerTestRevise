/* 

  SimpleRShellServer.c

  Created by Xinyuan Wang for CS 468

  All rights reserved.

*/

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <ifaddrs.h>
#include <strings.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>
#include <sys/wait.h>
#include <sys/errno.h>
#include <stdlib.h>
#include <stdbool.h>
#include <openssl/evp.h>
#include <openssl/ssl.h>
#include <openssl/rsa.h>
#include <openssl/x509.h>

#define DEBUG

int
serversock(int UDPorTCP, int portN, int qlen)
{
	struct sockaddr_in svr_addr;	/* my server endpoint address		*/
	int    sock;			/* socket descriptor to be allocated	*/

	if (portN<0 || portN>65535 || qlen<0)	/* sanity test of parameters */
		return -2;

	bzero((char *)&svr_addr, sizeof(svr_addr));
	svr_addr.sin_family = AF_INET;
	svr_addr.sin_addr.s_addr = INADDR_ANY;

    /* Set destination port number */
	svr_addr.sin_port = htons(portN);

    /* Allocate a socket */
	sock = socket(PF_INET, UDPorTCP, 0);
	if (sock < 0)
		return -3;

    /* Bind the socket */
	if (bind(sock, (struct sockaddr *)&svr_addr, sizeof(svr_addr)) < 0)
		return -4;

	if (UDPorTCP == SOCK_STREAM && listen(sock, qlen) < 0)
		return -5;

	return sock;
}

int 
serverTCPsock(int portN, int qlen) 
{
  return serversock(SOCK_STREAM, portN, qlen);
}

int 
serverUDPsock(int portN) 
{
  return serversock(SOCK_DGRAM, portN, 0);
}

void 
usage(char *self)
{
	fprintf(stderr, "Usage: %s port\n", self);
	exit(1);
}

void 
errmesg(char *msg)
{
	fprintf(stderr, "**** %s\n", msg);
	exit(1);

}

/*------------------------------------------------------------------------
 * reaper - clean up zombie children
 *------------------------------------------------------------------------
 */
void
reaper(int signum)
{
/*
	union wait	status;
*/

	int status;

	while (wait3(&status, WNOHANG, (struct rusage *)0) >= 0)
		/* empty */;
}

/*------------------------------------------------------------------------
 *  This is a very simplified remote shell, there are some shell command it 
	can not handle properly:

	cd
 *------------------------------------------------------------------------
 */
int
RemoteShellD(int sock)
{
#define	BUFSZ		65539
#define resultSz	65539
	char cmd[BUFSZ+20];
	char result[resultSz];
	int	cc, len;
	int resultAuth = 0;
	int rc=0;
	FILE *fp;

#ifdef DEBUG
	printf("***** RemoteShellD(sock=%d) called\n", sock);
#endif
	
	while ((cc = read(sock, cmd, BUFSZ)) > 0)	/* received something */
	{	
		
		if (cmd[cc-1]=='\n')
			cmd[cc-1]=0;
		else cmd[cc] = 0;

#ifdef DEBUG
		printf("***** RemoteShellD(%d): received %d bytes: `%s`\n", sock, cc, cmd);
#endif
		resultAuth = authenticateMain(cmd, cc, resultAuth, sock);	//Send the line to the authentication if the user has not been authenticated
		if ( resultAuth >= 5)
		{
		
			strcat(cmd, " 2>&1");
#ifdef DEBUG
			printf("***** cmd: `%s`\n", cmd); 
#endif 
			if ((fp=popen(cmd, "r"))==NULL)	/* stream open failed */
				return -1;

			/* stream open successful */

			while ((fgets(result, resultSz, fp)) != NULL)	/* got execution result */
			{
				len = strlen(result);
				printf("***** sending %d bytes result to client: \n`%s` \n", len, result);

				if (write(sock, result, len) < 0)
				{ rc=-1;
			  	break;
				}
			}
			fclose(fp);
		}

	}

	if (cc < 0)
		return -1;

	return rc;
}

/*------------------------------------------------------------------------
 * main - Concurrent TCP server 
 *------------------------------------------------------------------------
 */
int
main(int argc, char *argv[])
{
	int	 msock;			/* master server socket		*/
	int	 ssock;			/* slave server socket		*/
	int  portN;			/* port number to listen */
	struct sockaddr_in fromAddr;	/* the from address of a client	*/
	unsigned int  fromAddrLen;		/* from-address length          */
	int  prefixL, r;

	if (argc==2)
		portN = atoi(argv[1]);
	else usage(argv[0]);

	msock = serverTCPsock(portN, 5);


	(void) signal(SIGCHLD, reaper);

	while (1) 
	{
		fromAddrLen = sizeof(fromAddr);
		ssock = accept(msock, (struct sockaddr *)&fromAddr, &fromAddrLen);
		if (ssock < 0) {
			if (errno == EINTR)
				continue;
			errmesg("accept error\n");
		}

		switch (fork()) 
		{
			case 0:		/* child */
				close(msock);
				r=RemoteShellD(ssock);
				close(ssock);
				exit(r);

			default:	/* parent */
				(void) close(ssock);
				break;
			case -1:
				errmesg("fork error\n");
		}
	}
	close(msock);
}

/***************************************************************************************************************************************
 * New updated code for Homework 4
 * ************************************************************************************************************************************/
char workingBuffer[65539];
char userID[16] = "Alice";
char sentUserID[16];
unsigned char command[300];
uint32_t Nonce = 0;
uint32_t Nonce2 = 0;
/* A 256 bit key */
unsigned char *key = (unsigned char *)"70CCD9007338D6D81DD3B6271621B9CF";

/* A 128 bit IV */
unsigned char *iv = (unsigned char *)"0123456789012345";

int authenticateMain(char cmd[], int cc, int resultAuth, int sock)
{
		
	if ( resultAuth == 0 )
	{
		resultAuth = AuthenticateLevel1( cmd, cc, resultAuth);
		 resultAuth = AuthenticateLevel2( sock);
		return resultAuth;
	}
	if ( resultAuth == 1)
	{
		resultAuth = AuthenticateLevel2( sock);
		return resultAuth;
	}
	if ( resultAuth == 2 )
	{
		resultAuth = AuthenticateLevel3( cmd, cc, resultAuth);
		 if ( resultAuth == 3)
        	{
                	resultAuth = AuthenticateSucces(sock);
                	resultAuth = sendResults(sock);
			return resultAuth;
        	}
        	if ( resultAuth == -1)
        	{
                	resultAuth = AuthenticateFailure(sock);
                	return resultAuth;
        	}

		return resultAuth;
	}
	if ( resultAuth == 3)
	{
		resultAuth = AuthenticateSucces(sock);
		return resultAuth;
	}
	if ( resultAuth == -1)
	{
		resultAuth = AuthenticateFailure(sock);
		return resultAuth;
	}
	if ( resultAuth == 4)
	{
		resultAuth = sendResults(sock);
		return resultAuth;
	}


	return resultAuth;
}



int AuthenticateLevel1(char cmd[], int cc, int resultAuth)
{
	if ( cc == 0 )
	{
		printf("No Message checking again \n");
		return 0;
	}


	printf("RSHELL_REQ reciving \n");	
	if ( cc != 23 )
	{
		printf( " %s Is not the correct length it is %d \n" , cmd, cc);
		return 0;
	}
	
	uint16_t convertedShort = 0;
	uint16_t storageShort = 0;
	uint32_t convertedLong = 0;
	uint32_t storageLong = 0;

	if ( cmd[0] != 0x11)
	{
		printf("Value %c does not match %c \n", cmd[0], 0x11);
		return 0;
	}
	if ( cmd[1] == 0x7E)
	{
		storageShort = 0;
	}
	else
	{
		storageShort = cmd[1];
	}
	storageShort = (storageShort << 8);
	if ( cmd[2] == 0x7E)
	{
		storageShort = 0;
	}
	else
	{
		storageShort = cmd[2];
	}
	storageShort = (storageShort | cmd[2]);
	convertedShort = ntohs(storageShort);
	int length = convertedShort - 16;	//Stores the length of the payload minus user ID
	//printf("The length of our payload is %d \n", length);
	//char sentUserID[16];
	int index = 0;
	while ( index < 15)
	{
		sentUserID[index] = cmd[index+3];
		index++;
	}

	//Now to check the user Name
	
	index = 0;
	while ( index < 15)
	{
		if ( sentUserID[index] == userID[index])
		{
			index++;
		}
		else
		{
			if ( sentUserID[index] == 0x7E)
			{				
				sentUserID[index] = 0;				
				index++;
			}
			else
			{			
				printf( "Value %s does not equal %s \n", sentUserID, userID);
				return 0;
			}
		}
	}

	//printf("The user ID has been confirmed \n");
	storageLong = cmd[19];
	storageLong = ( storageLong << 8); //Move it for the next number
	storageLong = storageLong | cmd[20];
	storageLong = ( storageLong << 8 );
	storageLong = storageLong | cmd[21];
	storageLong = ( storageLong << 8);
	storageLong = storageLong | cmd[22];
	Nonce = ntohl(storageLong);
	//printf("Nonce 1 was %d \n", Nonce);
	//printf("User ID authenticated \n");
	return 1;
}

int AuthenticateLevel2(int sock)
{
	printf("AUTH_CHLG sending \n");	
	char responseBuffer[23];	
	int temp = 20;	
	int rc = rand();
	Nonce2 = (uint32_t)rc;
	//printf("Generated Nonce 2: %d \n", Nonce2);
	uint16_t convertedShort = 0;
	uint16_t storageShort = 0;
	uint32_t convertedLong = 0;
	uint32_t storageLong = 0;

	responseBuffer[0] = 0x12;
	//Length the the message will be 
	// 1 for the header
	// 2 for the length
	// 16 for the ID
	// 32 bit nonce2 or 4 bytes
	// 1+2+16+4 = 23 
	convertedShort = htons(temp);
	temp = convertedShort & 0xFF00;
	temp = ( temp >> 8);
	if ( temp == 0)
	{
		responseBuffer[1] = (char)0x7E;	//Using the binary value of 01111110 as a place holder for a zero value to allow transmission
	}
	else
	{
		responseBuffer[1] = (char)temp;
	}
	temp = convertedShort & 0x00FF;
	if ( temp == 0)
	{
		responseBuffer[2] = (char)0x7E;
	}
	else
	{
		responseBuffer[2] = (char)temp;
	}
	
	
	int index = 0;
	while ( index < 16)
	{
		responseBuffer[index+3] = userID[index];
		if ( responseBuffer[index+3] == 0)
		{
			responseBuffer[index+3] = 0x7E;
		}
		index++;
	}

	convertedLong = htonl(Nonce2);
	storageLong = convertedLong;
	storageLong = ( storageLong & 0xFF000000);
	storageLong = ( storageLong >> 24);
	responseBuffer[19] = storageLong;
	if ( responseBuffer[19] == 0)
	{
		responseBuffer[19] = 0x7E;
	}
	//printf("Entered the Nonce %c\n", responseBuffer[19]);
	storageLong = convertedLong;
	storageLong = ( storageLong & 0x00FF0000);
	storageLong = (storageLong >> 16);
	responseBuffer[20] = storageLong;
	if ( responseBuffer[20] == 0)
	{
		responseBuffer[20] = 0x7E;
	}
	//printf("Entered the Nonce %c\n", responseBuffer[20]);
	storageLong = convertedLong;
	storageLong = (storageLong & 0x0000FF00);
	storageLong = (storageLong >> 8);
	responseBuffer[21] = storageLong;
	if ( responseBuffer[21] == 0)
	{
		responseBuffer[21] = 0x7E;
	}
	//printf("Entered the Nonce %c\n", responseBuffer[21]);
	storageLong = convertedLong;
	storageLong = ( storageLong & 0x000000FF);
	responseBuffer[22] = storageLong;
	if ( responseBuffer[22] == 0)
	{
		responseBuffer[22] = 0x7E;
	}
	//printf("Entered the Nonce %c\n", responseBuffer[22]);

	//Sending the prepared Buffer
	int outchars = 23;
	int n = 0;

	if ((n=write(sock, responseBuffer, outchars))!=outchars)   /* send error */
        {
        	printf("RemoteShell has %d byte send when trying to send %d bytes to RemoteShell: `%s`\n", n, outchars, responseBuffer );
                close(sock);
                return 0;	//Forces a start over in authentication
        }
        
        printf("RemoteShell: sent %d bytes to RemoteShell: `%s`\n",  n, responseBuffer);
 
	return 2;	

	
	
}

int AuthenticateLevel3(char cmd[], int cc, int resultAuth)
{
	printf(" AUTH_RESP reciving \n");
	//printf("recieving buffer size: %d \n ", strlen(cmd));
	uint16_t convertedShort = 0;
	uint16_t storageShort = 0;
	uint32_t convertedLong = 0;
	uint32_t storageLong = 0;
	
	//int tempIndex = 0;
	//while (tempIndex < cc)
	//{
	//	printf( "%X", cmd[tempIndex]);
	//	tempIndex++;
	//}
	//printf("\n");

	if ( cmd[0] != 0x13)
	{
		printf("Value %c does not match %c \n", cmd[0], 0x13);
		//AuthenticateFailure( cmd, cc, resultAuth);
		return 0;
	}
	if ( cmd[1] == 0x7E)
	{
		storageShort = 0;
	}
	else
	{
		storageShort = cmd[1];
	}
	convertedShort = (storageShort << 8);

	//storageShort = (storageShort << 8);
	if ( cmd[2] == 0x7E)
	{
		storageShort = 0;
	}
	else
	{
		storageShort = cmd[2];
	}
	storageShort = (storageShort | convertedShort);
	convertedShort = ntohs(storageShort);
	int length = cc - 19;	//Stores the length of the payload
	//printf("the length of the message payload is %d \n", length);
	//char sentUserID[16];
	//printf("Getting the user ID \n");
	int index = 0;
	while ( index < 15)
	{
		sentUserID[index] = cmd[index+3];
		index++;
	}

	//Now to check the user Name
	
	index = 0;
	while ( index < 15)	//Last position is the null terminator
	{
		if ( sentUserID[index] == userID[index])
		{
			index++;
		}
		else
		{
			if ( sentUserID[index] == 0x7E)
			{				
				sentUserID[index] = 0;				
				index++;
			}
			else
			{			
				printf( "Value %s does not equal %s \n", sentUserID, userID);
				return -1;
			}
		}
	}
	//printf("User ID verified \n");
	//Now to handle the payload of the message
	unsigned char ciphertext[300];
	unsigned char payload[300];
	unsigned char NoncetoConvert[20];
	
	index = 0;
	//length = length *2;
	while ( index < length)	//Subtract the user ID length to get only the encrypted payload length
	{
		ciphertext[index] = cmd[index+19];
		index++;
	}

	int payloadLength = decrypt(ciphertext, length, key, iv, payload);
	//printf("Copying the payload to be decrypted \n");
	//Check the transmitted Nonce
	//printf("payload length: %d \n", payloadLength);
	storageLong = payload[0];
	storageLong = ( storageLong << 8); //Move it for the next number
	storageLong = storageLong | payload[1];
	storageLong = ( storageLong << 8 );
	storageLong = storageLong | payload[2];
	storageLong = ( storageLong << 8);
	storageLong = storageLong | payload[3];
	uint32_t Noncetemp = 0;
	Noncetemp = ntohl(storageLong);
	//Noncetemp = Nonce2 + 1;
	index = 4;
	while ( index < payloadLength)
	{
		command[index-4] = payload[index];
		//workingBuffer[index-4] = payload[index];	//Store result for the end
		index++;
	}
	if ( Noncetemp == (Nonce2 + 1))
	{
		//AuthenticateSucces(command, (index - 4));
		return 3;
	}
	else
	{
		printf("Nonce %d does not match fail %d \n", (Nonce2 + 1), Noncetemp);
		return -1;
		//AuthenticateFail(char cmd[], int cc, int resultAuth);
	}

	
	//printf("User ID authenticated \n");
	//return (resultAuth + 1);
	
	
}

int AuthenticateSucces( int sock)
{
	printf("Authentcation Sucess \n");	
	workingBuffer[0] = 0x14;
	uint16_t convertedShort = 0;
	uint16_t storageShort = 0;
	uint32_t convertedLong = 0;
	uint32_t storageLong = 0;
	uint32_t NonceTemp = Nonce + 1;
	//prepare the Nonce for transmission
	char payload[4];
	convertedLong = htonl(NonceTemp);
	storageLong = convertedLong;
	storageLong = ( storageLong & 0xFF000000);
	storageLong = ( storageLong >> 24);
	payload[0] = storageLong;
	if ( payload[0] == 0)
	{
		payload[0] = 0x7E;
	}
	//printf("Entered the Nonce %c\n", responseBuffer[19]);
	storageLong = convertedLong;
	storageLong = ( storageLong & 0x00FF0000);
	storageLong = (storageLong >> 16);
	payload[1] = storageLong;
	if ( payload[1] == 0)
	{
		payload[1] = 0x7E;
	}
	//printf("Entered the Nonce %c\n", responseBuffer[20]);
	storageLong = convertedLong;
	storageLong = (storageLong & 0x0000FF00);
	storageLong = (storageLong >> 8);
	payload[2] = storageLong;
	if ( payload[2] == 0)
	{
		payload[2] = 0x7E;
	}
	//printf("Entered the Nonce %c\n", responseBuffer[21]);
	storageLong = convertedLong;
	storageLong = ( storageLong & 0x000000FF);
	payload[3] = storageLong;
	if ( payload[3] == 0)
	{
		payload[3] = 0x7E;
	}
	unsigned char ciphertext[300];
	int ciphertext_len = encrypt( payload, strlen((char *)payload), key, iv, ciphertext);
	//printf("Generated Nonce 2: %d \n", Nonce2);
	
	convertedShort = htons(ciphertext_len + 16);
	int temp = convertedShort & 0xFF00;
	temp = ( temp >> 8);
	if ( temp == 0)
	{
		workingBuffer[1] = 0x7E;	//Using the binary value of 01111110 as a place holder for a zero value to allow transmission
	}
	else
	{
		workingBuffer[1] = temp;
	}
	temp = convertedShort & 0x00FF;
	if ( temp == 0)
	{
		workingBuffer[2] = 0x7E;
	}
	else
	{
		workingBuffer[2] = temp;
	}
	
	
	int index = 3;
	while ( index < 19)
	{
		workingBuffer[index] = userID[index-3];
		if ( workingBuffer[index] == 0)
		{
			workingBuffer[index] = 0x7E;
		}
		index++;
	}

	index = 19;
	while ( index < ( 19 + ciphertext_len))
	{
		workingBuffer[index] = ciphertext[index - 19];
		index++;
	} 

	//Sending the prepared Buffer
	int outchars = index;
	int n = 0;

	if ((n=write(sock, workingBuffer, outchars))!=outchars)   /* send error */
        {
        	printf("RemoteShell has %d byte send when trying to send %d bytes to RemoteShell: `%s`\n", n, outchars, workingBuffer );
                close(sock);
                return 0;	//Forces a start over in authentication
        }
        
        printf("RemoteShell: sent %d bytes to RemoteShell: `%s`\n",  n, workingBuffer);
 
	return 4;	

}	



int AuthenticateFailure( int sock)
{
	printf("Authentcation Failure \n");	
	char responseBuffer[23];	
	int temp = 23;	
	//int rc = rand();
	//Nonce2 = (uint32_t)rc;
	//printf("Generated Nonce 2: %d \n", Nonce2);
	uint16_t convertedShort = 0;
	uint16_t storageShort = 0;
	uint32_t convertedLong = 0;
	uint32_t storageLong = 0;

	responseBuffer[0] = 0x15;
	//Length the the message will be 
	// 1 for the header
	// 2 for the length
	// 16 for the ID
	// 32 bit nonce2 or 4 bytes
	// 1+2+16+4 = 23 
	convertedShort = htons(temp);
	temp = convertedShort & 0xFF00;
	temp = ( temp >> 8);
	if ( temp == 0)
	{
		responseBuffer[1] = 0x7E;	//Using the binary value of 01111110 as a place holder for a zero value to allow transmission
	}
	else
	{
		responseBuffer[1] = temp;
	}
	temp = convertedShort & 0x00FF;
	if ( temp == 0)
	{
		responseBuffer[2] = 0x7E;
	}
	else
	{
		responseBuffer[2] = temp;
	}
	
	
	int index = 0;
	while ( index < 16)
	{
		responseBuffer[index+3] = userID[index];
		if ( responseBuffer[index+3] == 0)
		{
			responseBuffer[index+3] = 0x7E;
		}
		index++;
	}

	convertedLong = htonl(Nonce);
	storageLong = convertedLong;
	storageLong = ( storageLong & 0xFF000000);
	storageLong = ( storageLong >> 24);
	responseBuffer[19] = storageLong;
	if ( responseBuffer[19] == 0)
	{
		responseBuffer[19] = 0x7E;
	}
	//printf("Entered the Nonce %c\n", responseBuffer[19]);
	storageLong = convertedLong;
	storageLong = ( storageLong & 0x00FF0000);
	storageLong = (storageLong >> 16);
	responseBuffer[20] = storageLong;
	if ( responseBuffer[20] == 0)
	{
		responseBuffer[20] = 0x7E;
	}
	//printf("Entered the Nonce %c\n", responseBuffer[20]);
	storageLong = convertedLong;
	storageLong = (storageLong & 0x0000FF00);
	storageLong = (storageLong >> 8);
	responseBuffer[21] = storageLong;
	if ( responseBuffer[21] == 0)
	{
		responseBuffer[21] = 0x7E;
	}
	//printf("Entered the Nonce %c\n", responseBuffer[21]);
	storageLong = convertedLong;
	storageLong = ( storageLong & 0x000000FF);
	responseBuffer[22] = storageLong;
	if ( responseBuffer[22] == 0)
	{
		responseBuffer[22] = 0x7E;
	}
	//printf("Entered the Nonce %c\n", responseBuffer[22]);

	//Sending the prepared Buffer
	int outchars = 23;
	int n = 0;

	if ((n=write(sock, responseBuffer, outchars))!=outchars)   /* send error */
        {
        	printf("RemoteShell has %d byte send when trying to send %d bytes to RemoteShell: `%s`\n", n, outchars, responseBuffer );
                close(sock);
                return 0;	//Forces a start over in authentication
        }
        
        printf("RemoteShell: sent %d bytes to RemoteShell: `%s`\n",  n, responseBuffer);
 
	return 0;	

	
}	


int decrypt(unsigned char *ciphertext, int ciphertext_len, unsigned char *key, unsigned char *iv, unsigned char *plaintext)
{
    EVP_CIPHER_CTX *ctx;

    int len;

    int plaintext_len;

    /* Create and initialise the context */
    if(!(ctx = EVP_CIPHER_CTX_new()))
        handleErrors();

    /*
     * Initialise the decryption operation. IMPORTANT - ensure you use a key
     * and IV size appropriate for your cipher
     * In this example we are using 256 bit AES (i.e. a 256 bit key). The
     * IV size for *most* modes is the same as the block size. For AES this
     * is 128 bits
     */
    if(1 != EVP_DecryptInit_ex(ctx, EVP_aes_256_cbc(), NULL, key, iv))
        handleErrors();

    /*
     * Provide the message to be decrypted, and obtain the plaintext output.
     * EVP_DecryptUpdate can be called multiple times if necessary.
     */
    if(1 != EVP_DecryptUpdate(ctx, plaintext, &len, ciphertext, ciphertext_len))
        handleErrors();
    plaintext_len = len;

    /*
     * Finalise the decryption. Further plaintext bytes may be written at
     * this stage.
     */
    if(1 != EVP_DecryptFinal_ex(ctx, plaintext + len, &len))
        handleErrors();
    plaintext_len += len;

    /* Clean up */
    EVP_CIPHER_CTX_free(ctx);

    return plaintext_len;
}

int encrypt(unsigned char *plaintext, int plaintext_len, unsigned char *key, unsigned char *iv, unsigned char *ciphertext)
{
    EVP_CIPHER_CTX *ctx;

    int len;

    int ciphertext_len;

    /* Create and initialise the context */
    if(!(ctx = EVP_CIPHER_CTX_new()))
        handleErrors();

    /*
     * Initialise the encryption operation. IMPORTANT - ensure you use a key
     * and IV size appropriate for your cipher
     * In this example we are using 256 bit AES (i.e. a 256 bit key). The
     * IV size for *most* modes is the same as the block size. For AES this
     * is 128 bits
     */
    if(1 != EVP_EncryptInit_ex(ctx, EVP_aes_256_cbc(), NULL, key, iv))
        handleErrors();

    /*
     * Provide the message to be encrypted, and obtain the encrypted output.
     * EVP_EncryptUpdate can be called multiple times if necessary
     */
    if(1 != EVP_EncryptUpdate(ctx, ciphertext, &len, plaintext, plaintext_len))
        handleErrors();
    ciphertext_len = len;

    /*
     * Finalise the encryption. Further ciphertext bytes may be written at
     * this stage.
     */
    if(1 != EVP_EncryptFinal_ex(ctx, ciphertext + len, &len))
        handleErrors();
    ciphertext_len += len;

    /* Clean up */
    EVP_CIPHER_CTX_free(ctx);

    return ciphertext_len;
}

int sendResults(int sock)
{
	printf("Success Sending results \n");
	workingBuffer[0] = 0x16;
	char cmd[BUFSZ+20];
	char result[resultSz];
	int	cc, len;
	int resultAuth = 0;
	int index = 0;
	uint16_t convertedShort = 0;
	uint16_t storageShort = 0;
	uint32_t convertedLong = 0;
	uint32_t storageLong = 0;

	while ( index < strlen(command))
	{
		cmd[index] = command[index];
		index++;
	}
	int rc=0;
	FILE *fp;
	strcat(cmd, " 2>&1");
	#ifdef DEBUG
	printf("***** cmd: `%s`\n", cmd); 
	#endif 
	if ((fp=popen(cmd, "r"))==NULL)	/* stream open failed */
		return -1;

	/* stream open successful */

	while ((fgets(result, resultSz, fp)) != NULL)	/* got execution result */
	{
		len = strlen(result);
		printf("***** sending %d bytes result to client: \n`%s` \n", len, result);

		if (write(sock, result, len) < 0)
		{ 
			rc=-1;
		  	break;
		}
	}
	fclose(fp);
	
	
	//insert userID
	index = 3;
	while ( index < 19)
	{
		workingBuffer[index] = userID[index-3];
		if ( workingBuffer[index] == 0)
		{
			workingBuffer[index] = 0x7E;
		}
		index++;
	}

	unsigned char ciphertext[300];
	int ciphertext_len = encrypt( result, strlen((char *)result), key, iv, ciphertext);
	
	//Add this to the Message
	//
	index = 0;
	while ( index < ciphertext_len)
	{
		workingBuffer[index+19] = ciphertext[index];
		index++;
	} 

	int payloadLength = ciphertext_len + 16;
	
	

	convertedShort = htons(payloadLength);
	int temp = convertedShort & 0xFF00;
	temp = ( temp >> 8);
	if ( temp == 0)
	{
		workingBuffer[1] = 0x7E;	//Using the binary value of 01111110 as a place holder for a zero value to allow transmission
	}
	else
	{
		workingBuffer[1] = temp;
	}
	temp = convertedShort & 0x00FF;
	if ( temp == 0)
	{
		workingBuffer[2] = 0x7E;
	}
	else
	{
		workingBuffer[2] = temp;
	}

	//transmit the result

	int outchars = index;
	int n = 0;

	if ((n=write(sock, workingBuffer, outchars))!=outchars)   /* send error */
        {
        	printf("RemoteShell has %d byte send when trying to send %d bytes to RemoteShell: `%s`\n", n, outchars, workingBuffer );
                close(sock);
                return 0;	//Forces a start over in authentication
        }
        
        printf("RemoteShell: sent %d bytes to RemoteShell: `%s`\n",  n, workingBuffer);
 
	return 0;	

}

void handleErrors()
{
	printf("ERROR IN THE ENCRYPTION FUNCTION \n");
}

int AuthenticateFail()
{
	return 0;
}

